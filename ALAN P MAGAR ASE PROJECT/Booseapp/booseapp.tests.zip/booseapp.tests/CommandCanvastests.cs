﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using booseapp;   // 👈 this lets us use CommandCanvas

namespace booseapp.tests
{
    [TestClass]
    public class CommandCanvasTests
    {
        [TestMethod]
        public void MoveTo_Sets_X_And_Y()
        {
            // Arrange
            var canvas = new CommandCanvas();

            // Act
            canvas.MoveTo(100, 50);

            // Assert
            Assert.AreEqual(100, canvas.Xpos);
            Assert.AreEqual(50, canvas.Ypos);
        }

        [TestMethod]
        public void DrawTo_Changes_Position()
        {
            var canvas = new CommandCanvas();

            canvas.MoveTo(10, 10);
            canvas.DrawTo(40, 60);

            Assert.AreEqual(40, canvas.Xpos);
            Assert.AreEqual(60, canvas.Ypos);
        }

        [TestMethod]
        public void Reset_Sets_Position_Back_To_0_0()
        {
            var canvas = new CommandCanvas();

            canvas.MoveTo(200, 200);
            canvas.Reset();

            Assert.AreEqual(0, canvas.Xpos);
            Assert.AreEqual(0, canvas.Ypos);
        }

        [TestMethod]
        [ExpectedException(typeof(System.ArgumentOutOfRangeException))]    
        public void Circle_Negative_Radius_Throws_Exception()
        {
            var canvas = new CommandCanvas();

            canvas.Circle(-5, false);
        }

        [TestMethod] 
        public void Set_Does_Not_Throw_For_Valid_Size()
        {
            var canvas = new CommandCanvas();

            canvas.Set(800, 600);
            // If it doesn’t throw, test passes.
        }
    }
}
